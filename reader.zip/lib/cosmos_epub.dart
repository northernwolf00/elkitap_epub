library cosmos_epub;

import 'dart:io';

import 'package:cosmos_epub/Component/constants.dart';
import 'package:cosmos_epub/Helpers/isar_service.dart';
import 'package:cosmos_epub/Helpers/progress_singleton.dart';
import 'package:cosmos_epub/Model/book_progress_model.dart';
import 'package:cosmos_epub/show_epub.dart';
import 'package:epubx/epubx.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:get_storage/get_storage.dart';
import 'package:get/get.dart';

import 'package:http/http.dart' as http;

///TODO: Optimize with isolates

class CosmosEpub {
  static final GlobalKey<NavigatorState> navigatorKey =
      GlobalKey<NavigatorState>();

  static bool _initialized = false;

  // Add locale reactive variable
  static final Rx<Locale> _locale = Locale('tr', 'TR').obs;
  static Rx<Locale> get localeStream => _locale;

  // Getter for current locale
  static Locale get currentLocale => _locale.value;

  static Future<void> Function(String bookId, String text)? _onAddNoteHandler;
  static Future<void> Function(String bookId)? _onAddToShelfHandler;

  static String bookDescription = '';

  // Global state for shelf and my books
  static bool isInShelf = false;
  static bool isInMyBooks = false;

  // Method to update locale
  static void updateLocale(Locale locale) {
    _locale.value = locale;
  }

  static void registerAddNoteHandler(
      Future<void> Function(String bookId, String text) handler) {
    _onAddNoteHandler = handler;
  }

  static void registerAddToShelfHandler(
      Future<void> Function(String bookId) handler) {
    _onAddToShelfHandler = handler;
  }

  static Future<void> onAddToShelf(String bookId) async {
    if (_onAddToShelfHandler != null) {
      await _onAddToShelfHandler!(bookId);
    }
    // Toggle the state
    isInShelf = !isInShelf;
  }

  static Future<void> Function(String bookId)? _onSaveToMyBooksHandler;

  static void registerSaveToMyBooksHandler(
      Future<void> Function(String bookId) handler) {
    _onSaveToMyBooksHandler = handler;
  }

  static Future<void> onSaveToMyBooks(String bookId) async {
    if (_onSaveToMyBooksHandler != null) {
      await _onSaveToMyBooksHandler!(bookId);
    }
    // Toggle the state
    isInMyBooks = !isInMyBooks;
  }

  static Future<void> openLocalBook(
      {required String localPath,
      required BuildContext context,
      required String bookId,
      required String imageUrl,
      Color accentColor = Colors.indigoAccent,
      Function(int currentPage, int totalPages)? onPageFlip,
      Function(int lastPageIndex)? onLastPage,
      String chapterListTitle = 'Table of Contents',
      bool shouldOpenDrawer = false,
      String bookDescription = '',
      bool isInShelf = false,
      bool isInMyBooks = false,
      int starterChapter = -1}) async {
    debugPrint('📚 Opening local book from path: $localPath');
    var bytes = await File(localPath).readAsBytes();
    EpubBook epubBook = await EpubReader.readBook(bytes.buffer.asUint8List());

    if (!context.mounted) return;
    await _openBook(
        context: context,
        epubBook: epubBook,
        bookId: bookId,
        imageUrl: imageUrl,
        shouldOpenDrawer: shouldOpenDrawer,
        starterChapter: starterChapter,
        chapterListTitle: chapterListTitle,
        bookDescription: bookDescription,
        isInShelf: isInShelf,
        isInMyBooks: isInMyBooks,
        onPageFlip: onPageFlip,
        onLastPage: onLastPage,
        accentColor: accentColor);
  }

  static Future<void> openFileBook(
      {required Uint8List bytes,
      required BuildContext context,
      required String bookId,
      required String imageUrl,
      Color accentColor = Colors.indigoAccent,
      Function(int currentPage, int totalPages)? onPageFlip,
      Function(int lastPageIndex)? onLastPage,
      String chapterListTitle = 'Table of Contents',
      bool shouldOpenDrawer = false,
      String bookDescription = '',
      bool isInShelf = false,
      bool isInMyBooks = false,
      int starterChapter = -1}) async {
    EpubBook epubBook = await EpubReader.readBook(bytes.buffer.asUint8List());

    if (!context.mounted) return;
    await _openBook(
        context: context,
        epubBook: epubBook,
        bookId: bookId,
        imageUrl: imageUrl,
        shouldOpenDrawer: shouldOpenDrawer,
        starterChapter: starterChapter,
        chapterListTitle: chapterListTitle,
        bookDescription: bookDescription,
        isInShelf: isInShelf,
        isInMyBooks: isInMyBooks,
        onPageFlip: onPageFlip,
        onLastPage: onLastPage,
        accentColor: accentColor);
  }

  static Future<void> openURLBook(
      {required String urlPath,
      required BuildContext context,
      Color accentColor = Colors.indigoAccent,
      Function(int currentPage, int totalPages)? onPageFlip,
      Function(int lastPageIndex)? onLastPage,
      required String bookId,
      required String imageUrl,
      String chapterListTitle = 'Table of Contents',
      bool shouldOpenDrawer = false,
      String bookDescription = '',
      bool isInShelf = false,
      bool isInMyBooks = false,
      int starterChapter = -1}) async {
    debugPrint('📚 Downloading book from URL: $urlPath');
    final result = await http.get(Uri.parse(urlPath));
    final bytes = result.bodyBytes;
    debugPrint('✅ Book downloaded successfully, size: ${bytes.length} bytes');
    EpubBook epubBook = await EpubReader.readBook(bytes.buffer.asUint8List());

    if (!context.mounted) return;
    await _openBook(
        context: context,
        epubBook: epubBook,
        bookId: bookId,
        imageUrl: imageUrl,
        shouldOpenDrawer: shouldOpenDrawer,
        starterChapter: starterChapter,
        chapterListTitle: chapterListTitle,
        bookDescription: bookDescription,
        isInShelf: isInShelf,
        isInMyBooks: isInMyBooks,
        onPageFlip: onPageFlip,
        onLastPage: onLastPage,
        accentColor: accentColor);
  }

  static Future<void> openAssetBook(
      {required String assetPath,
      required BuildContext context,
      required String imageUrl,
      Color accentColor = Colors.indigoAccent,
      Function(int currentPage, int totalPages)? onPageFlip,
      Function(int lastPageIndex)? onLastPage,
      required String bookId,
      String chapterListTitle = 'Table of Contents',
      bool shouldOpenDrawer = false,
      String bookDescription = '',
      bool isInShelf = false,
      bool isInMyBooks = false,
      int starterChapter = -1}) async {
    debugPrint('📚 Opening book from asset: $assetPath');
    var bytes = await rootBundle.load(assetPath);
    EpubBook epubBook = await EpubReader.readBook(bytes.buffer.asUint8List());

    if (!context.mounted) return;
    await _openBook(
        context: context,
        epubBook: epubBook,
        imageUrl: imageUrl,
        bookId: bookId,
        shouldOpenDrawer: shouldOpenDrawer,
        starterChapter: starterChapter,
        chapterListTitle: chapterListTitle,
        bookDescription: bookDescription,
        isInShelf: isInShelf,
        isInMyBooks: isInMyBooks,
        onPageFlip: onPageFlip,
        onLastPage: onLastPage,
        accentColor: accentColor);
  }

  static _openBook(
      {required BuildContext context,
      required EpubBook epubBook,
      required String imageUrl,
      required String bookId,
      required bool shouldOpenDrawer,
      required Color accentColor,
      required int starterChapter,
      required String chapterListTitle,
      String bookDescription = '',
      bool isInShelf = false,
      bool isInMyBooks = false,
      Function(int currentPage, int totalPages)? onPageFlip,
      Function(int lastPageIndex)? onLastPage}) async {
    CosmosEpub.bookDescription = bookDescription;
    CosmosEpub.isInShelf = isInShelf;
    CosmosEpub.isInMyBooks = isInMyBooks;
    _checkInitialization();

    ///Set starter chapter as current
    if (starterChapter != -1) {
      await bookProgress.setCurrentChapterIndex(bookId, starterChapter);
      await bookProgress.setCurrentPageIndex(bookId, 0);
    }

    debugPrint('🔀 _openBook called for bookId: $bookId');
    debugPrint('🔀 Context mounted: ${context.mounted}');

    if (!context.mounted) {
      debugPrint('⚠️ Context not mounted, cannot navigate');
      return;
    }

    // Use Navigator.push for better compatibility with both GetX and non-GetX apps
    await Navigator.of(context).pushReplacement(
      MaterialPageRoute(
        builder: (context) => ShowEpub(
          epubBook: epubBook,
          starterChapter: starterChapter >= 0
              ? starterChapter
              : bookProgress.getBookProgress(bookId).currentChapterIndex ?? 0,
          shouldOpenDrawer: shouldOpenDrawer,
          bookId: bookId,
          imageUrl: imageUrl,
          accentColor: accentColor,
          chapterListTitle: chapterListTitle,
          onPageFlip: onPageFlip,
          onLastPage: onLastPage,
        ),
      ),
    );

    debugPrint('🔀 Navigation completed');
  }

// Inside CosmosEpub class
  static Future<void> addNote({
    required String bookId,
    required String selectedText,
    BuildContext? context,
  }) async {
    _checkInitialization();

    if (_onAddNoteHandler != null) {
      // ✅ Use the registered custom handler
      await _onAddNoteHandler!(bookId, selectedText);
    } else {
      // ⚙️ Default fallback if no handler is registered
      debugPrint('Note added for $bookId: $selectedText');

      if (context != null && context.mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Note added: "${_truncate(selectedText)}"'),
            backgroundColor: Colors.indigoAccent,
            behavior: SnackBarBehavior.floating,
            duration: const Duration(seconds: 2),
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(10),
            ),
          ),
        );
      }
    }
  }

  static String _truncate(String text, [int maxLength = 50]) {
    return text.length <= maxLength
        ? text
        : '${text.substring(0, maxLength)}...';
  }

  static Future<bool> initialize() async {
    await ScreenUtil.ensureScreenSize();
    await GetStorage.init();
    var isar = await IsarService.buildIsarService();
    bookProgress = BookProgressSingleton(isar: isar);

    // Initialize with app's current locale
    _locale.value = Get.locale ?? Locale('tr', 'TR');

    _initialized = true;
    return true;
  }

  static _checkInitialization() {
    if (!_initialized) {
      throw Exception(
          'CosmosEpub is not initialized. Please call initialize() before using other methods. For more info pls read the docs');
    }
  }

  static Future<bool> clearThemeCache() async {
    if (await GetStorage().initStorage) {
      var get = GetStorage();
      await get.remove(libTheme);
      await get.remove(libFont);
      await get.remove(libFontSize);
      return true;
    } else {
      return false;
    }
  }

  static Future<bool> setCurrentPageIndex(String bookId, int index) async {
    return await bookProgress.setCurrentPageIndex(bookId, index);
  }

  static Future<bool> setCurrentChapterIndex(String bookId, int index) async {
    return await bookProgress.setCurrentChapterIndex(bookId, index);
  }

  static BookProgressModel getBookProgress(String bookId) {
    return bookProgress.getBookProgress(bookId);
  }

  static Future<bool> deleteBookProgress(String bookId) async {
    return await bookProgress.deleteBookProgress(bookId);
  }

  static Future<bool> deleteAllBooksProgress() async {
    return await bookProgress.deleteAllBooksProgress();
  }
}
