import 'package:cosmos_epub/cosmos_epub.dart';
import 'package:cosmos_epub/translations/epub_translations.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:share_plus/share_plus.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:get/get.dart';

/// Custom iOS-style selectable text widget
class CustomSelectableText extends StatefulWidget {
  final String text;
  final TextStyle style;
  final TextDirection textDirection;
  final String bookId;
  final Color? selectionColor;
  final TextAlign textAlign;

  const CustomSelectableText({
    super.key,
    required this.text,
    required this.style,
    required this.textDirection,
    required this.bookId,
    this.selectionColor,
    this.textAlign = TextAlign.justify,
  });

  @override
  State<CustomSelectableText> createState() => _CustomSelectableTextState();
}

class _CustomSelectableTextState extends State<CustomSelectableText> {
  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final isDark = theme.brightness == Brightness.dark;

    return TextSelectionTheme(
      data: TextSelectionThemeData(
        selectionColor: widget.selectionColor,
      ),
      child: SelectableText(
        widget.text,
        style: widget.style,
        textDirection: widget.textDirection,
        textAlign: widget.textAlign,
        contextMenuBuilder: (context, editableTextState) {
          return _CustomTextSelectionToolbar(
            editableTextState: editableTextState,
            bookId: widget.bookId,
            isDark: isDark,
          );
        },
      ),
    );
  }
}

/// Custom iOS-style text selection toolbar
class _CustomTextSelectionToolbar extends StatelessWidget {
  final EditableTextState editableTextState;
  final String bookId;
  final bool isDark;

  const _CustomTextSelectionToolbar({
    required this.editableTextState,
    required this.bookId,
    required this.isDark,
  });

  @override
  Widget build(BuildContext context) {
    final TextEditingValue value = editableTextState.textEditingValue;
    final String selectedText = value.selection.textInside(value.text);

    if (selectedText.isEmpty) {
      return const SizedBox.shrink();
    }

    // Get anchor points for positioning
    final List<TextSelectionPoint> endpoints = editableTextState.renderEditable
        .getEndpointsForSelection(value.selection);

    if (endpoints.isEmpty) {
      return const SizedBox.shrink();
    }

    // Calculate position above the selection
    final Offset anchor = endpoints.first.point;

    return _buildToolbar(context, anchor, selectedText);
  }

  Widget _buildToolbar(
      BuildContext context, Offset anchor, String selectedText) {
    return Stack(
      children: [
        Positioned(
          top: anchor.dy - 60, // Position above selection
          left: anchor.dx.clamp(20.0, MediaQuery.of(context).size.width - 300),
          child: Material(
            elevation: 8,
            borderRadius: BorderRadius.circular(12),
            color: isDark ? Colors.black : Colors.white,
            shadowColor: isDark
                ? Colors.white.withValues(alpha: 0.2)
                : Colors.black.withValues(alpha: 0.3),
            child: Container(
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(12),
                border: Border.all(
                  color: isDark
                      ? Colors.white.withValues(alpha: 0.1)
                      : Colors.black.withValues(alpha: 0.1),
                  width: 0.5,
                ),
              ),
              child: Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  _buildToolbarButton(
                    context,
                    CosmosEpubLocalization.t('add_note'),
                    () => _handleAddNote(context, selectedText),
                  ),
                  _buildDivider(),
                  _buildToolbarButton(
                    context,
                    CosmosEpubLocalization.t('share'),
                    () => _handleShare(context, selectedText),
                  ),
                  _buildDivider(),
                  _buildToolbarButton(
                    context,
                    CosmosEpubLocalization.t('copy'),
                    () => _handleCopy(context, selectedText),
                  ),
                ],
              ),
            ),
          ),
        ),
      ],
    );
  }

  Widget _buildToolbarButton(
      BuildContext context, String label, VoidCallback onPressed) {
    return InkWell(
      onTap: () {
        onPressed();
        // Clear selection after action
        editableTextState.userUpdateTextEditingValue(
          editableTextState.textEditingValue.copyWith(
            selection: const TextSelection.collapsed(offset: 0),
          ),
          SelectionChangedCause.toolbar,
        );
      },
      borderRadius: BorderRadius.circular(12),
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 12),
        child: Text(
          label,
          style: TextStyle(
            fontSize: 15,
            color: isDark ? Colors.white : Colors.black87,
            fontWeight: FontWeight.w400,
          ),
        ),
      ),
    );
  }

  Widget _buildDivider() {
    return Container(
      width: 1,
      height: 30,
      color: isDark
          ? Colors.white.withValues(alpha: 0.15)
          : Colors.black.withValues(alpha: 0.15),
    );
  }

  void _handleAddNote(BuildContext context, String selectedText) {
    _showAddNoteBottomSheet(context, selectedText);
  }

  void _handleShare(BuildContext context, String selectedText) {
    final box = context.findRenderObject() as RenderBox?;
    if (box == null) return;

    final position = box.localToGlobal(Offset.zero) & box.size;

    SharePlus.instance.share(
      ShareParams(
        text: selectedText,
        sharePositionOrigin: position,
      ),
    );
  }

  void _handleCopy(BuildContext context, String selectedText) {
    Clipboard.setData(ClipboardData(text: selectedText));

    // Show feedback
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(CosmosEpubLocalization.t('copied')),
        duration: const Duration(seconds: 1),
        behavior: SnackBarBehavior.floating,
      ),
    );
  }

  void _showAddNoteBottomSheet(BuildContext context, String selectedText) {
    final textController = TextEditingController(text: '');
    final selectedColor = Colors.blue.obs;

    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      isDismissible: true,
      enableDrag: true,
      builder: (context) => Padding(
        padding: EdgeInsets.only(
          bottom: MediaQuery.of(context).viewInsets.bottom,
        ),
        child: Obx(() => Container(
              height: MediaQuery.of(context).size.height * 0.9,
              decoration: BoxDecoration(
                color: Theme.of(context).brightness == Brightness.dark
                    ? Colors.black
                    : Colors.white,
                borderRadius:
                    const BorderRadius.vertical(top: Radius.circular(20)),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  // Header
                  Padding(
                    padding: const EdgeInsets.all(16),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Text(
                          CosmosEpubLocalization.t('note'),
                          style: const TextStyle(
                              fontSize: 17, fontWeight: FontWeight.bold),
                        ),
                        TextButton(
                          onPressed: () async {
                            final note = textController.text.trim();
                            Navigator.pop(context);
                            await CosmosEpub.addNote(
                              bookId: bookId,
                              selectedText: note.isEmpty
                                  ? selectedText
                                  : '$selectedText\n\n$note',
                              context: context,
                            );
                          },
                          child: Text(
                            CosmosEpubLocalization.t('done'),
                            style: TextStyle(
                              fontSize: 17,
                              color: Theme.of(context).brightness ==
                                      Brightness.dark
                                  ? Colors.white
                                  : Colors.black,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                  // Selected text display with left border
                  Container(
                    margin:
                        EdgeInsets.symmetric(horizontal: 16.w, vertical: 12.h),
                    padding: EdgeInsets.only(left: 12.w, top: 4.h, bottom: 4.h),
                    decoration: BoxDecoration(
                      border: Border(
                        left: BorderSide(
                          color: selectedColor.value,
                          width: 3.w,
                        ),
                      ),
                    ),
                    child: Text(
                      selectedText,
                      textAlign: TextAlign.start,
                      style: TextStyle(
                        fontSize: 16.sp,
                        fontWeight: FontWeight.w400,
                        color: Theme.of(context).brightness == Brightness.dark
                            ? Colors.white
                            : Colors.black,
                      ),
                    ),
                  ),
                  // Note input
                  Expanded(
                    child: Container(
                      margin: const EdgeInsets.symmetric(horizontal: 16),
                      padding: const EdgeInsets.only(left: 12),
                      child: TextField(
                        controller: textController,
                        maxLines: null,
                        expands: true,
                        textAlignVertical: TextAlignVertical.top,
                        decoration: InputDecoration(
                          border: InputBorder.none,
                          hintText: CosmosEpubLocalization.t('add_note_hint'),
                        ),
                        style: const TextStyle(fontSize: 17),
                      ),
                    ),
                  ),
                  // Color picker
                  Container(
                    padding:
                        const EdgeInsets.symmetric(vertical: 16, horizontal: 8),
                    decoration: BoxDecoration(
                      color: Theme.of(context).brightness == Brightness.dark
                          ? Colors.black
                          : Colors.white,
                      border: Border(
                        top: BorderSide(
                          color: Colors.grey.withValues(alpha: 0.3),
                          width: 1,
                        ),
                      ),
                    ),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                      children: [
                        Colors.grey,
                        Colors.red,
                        Colors.amber,
                        Colors.brown,
                        Colors.purple,
                        Colors.green,
                        Colors.blue,
                      ]
                          .map((color) => GestureDetector(
                                onTap: () => selectedColor.value = color,
                                child: Container(
                                  width: 40,
                                  height: 40,
                                  decoration: BoxDecoration(
                                    color: color,
                                    shape: BoxShape.circle,
                                    border: selectedColor.value == color
                                        ? Border.all(
                                            color:
                                                Theme.of(context).brightness ==
                                                        Brightness.dark
                                                    ? Colors.white
                                                    : Colors.black,
                                            width: 3,
                                          )
                                        : null,
                                  ),
                                ),
                              ))
                          .toList(),
                    ),
                  ),
                  SizedBox(height: MediaQuery.of(context).padding.bottom),
                ],
              ),
            )),
      ),
    );
  }
}

/// Custom Rich Text with selection support
class CustomSelectableRichText extends StatelessWidget {
  final TextSpan textSpan;
  final TextDirection textDirection;
  final String bookId;
  final Color? selectionColor;
  final TextAlign textAlign;

  const CustomSelectableRichText({
    super.key,
    required this.textSpan,
    required this.textDirection,
    required this.bookId,
    this.selectionColor,
    this.textAlign = TextAlign.left,
  });

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final isDark = theme.brightness == Brightness.dark;

    return TextSelectionTheme(
      data: TextSelectionThemeData(
        selectionColor: selectionColor,
      ),
      child: SelectableText.rich(
        textSpan,
        textDirection: textDirection,
        textAlign: textAlign,
        contextMenuBuilder: (context, editableTextState) {
          return _CustomTextSelectionToolbar(
            editableTextState: editableTextState,
            bookId: bookId,
            isDark: isDark,
          );
        },
      ),
    );
  }
}
